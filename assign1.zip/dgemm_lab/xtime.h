#ifndef __XTIME_H
#define __XTIME_H

void init_timer(void);
double xtime(void);

#endif
