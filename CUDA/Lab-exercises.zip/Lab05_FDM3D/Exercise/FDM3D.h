#ifndef __STENCIL_H
#define __STENCIL_H

#define RADIUS 4

#define BLOCK_DIM_X 8
#define BLOCK_DIM_Y 8

#endif /* STENCIL_H */

/* vim:set backspace=2 tabstop=4 shiftwidth=4 textwidth=120 foldmethod=marker expandtab: */
